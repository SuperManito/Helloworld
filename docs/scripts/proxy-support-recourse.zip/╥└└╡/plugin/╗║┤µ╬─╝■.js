//#host:.*
//#order:-99999

let req = __context.request()
let originalUrl = req.originalUrl();

if (originalUrl.indexOf(".baidu.com") < 0) {
    __context.continue()
    return
}

if (originalUrl.includes("?")) {
    originalUrl = originalUrl.substring(0, originalUrl.indexOf("?"))
}

//url判断

if (!originalUrl.endsWith(".js")) {
    __context.continue()
    return
}

let fileName = originalUrl
if (fileName.includes("#")) {
    fileName = fileName.substring(0, fileName.indexOf("#"))
}

fileName = "cache/" + fileName.replace(/https?:\/\//, "").replace(/\//g, "##")
try {
    let str = __utils.readFile(fileName)
    let res = __context.doBlock()
    res.setStatus(200)
        .setHeader("content-type", "text/javascript; charset=utf-8")
    console.log("成功读取缓存文件", originalUrl)
    res.setBody(str)
} catch (e) {
    console.log("未找到缓存文件,尝试缓存", originalUrl)
    let res = __context.doRequest();
    var body = res.body();
    if (body.length>10){
        __utils.writeFile(fileName, body)
        console.log("成功缓存文件", originalUrl)
    }else{
        console.log("文件过小,本次不缓存", originalUrl)
    }
}