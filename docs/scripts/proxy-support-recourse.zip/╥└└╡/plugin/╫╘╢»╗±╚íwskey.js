//#host:.*
//#order:199

__context.continue()
let cookie = __context.request().header('cookie');
if (!cookie || cookie.indexOf('pin') === -1) {
    return
}
let ckObj = cookie.split(";").map(s => s.split("="))
    .reduce((obj, arr) => (obj[(arr[0] + "").trim()] = (arr[1] + "").trim(), obj), {})
let pin = ckObj.pin || ckObj.pt_pin || ckObj.pwdt_id;
let wskey = ckObj.wskey;
const key = "wskey-" + pin;
if (wskey && pin) {
    let oldWskey = __context.globalGet(key) || "";
    //没有这个wskey或者已更新
    let prefix = "设置中";
    let setting = prefix + Math.random();
    if (wskey && pin && !oldWskey.startsWith(prefix) && wskey !== oldWskey) {
        __context.globalSet(key, setting);
        let lockValue = __context.globalGet(key);
        if (setting === lockValue) {
            __context.globalSet(key, wskey);
            let ok = false
            try {
                ok = doSend(key, pin, wskey)
            } finally {
                if (!ok) {
                    __context.globalSet(key, null);
                }
            }
        }
    }
}

function doSend(key, pin, wskey) {
    const config = require("./lib/config")
    let ok = false
    ok = sendHelloWorld(config, key, pin, wskey) || ok
    ok = sendTgBot(config, key, pin, wskey, ok) || ok
    ok || sendOther(config, key, pin, wskey)
    return true
}

function sendOther(config, key, pin, wskey) {
    console.log(`抓取到wskey,但是没有推送,需要用户手动复制: pin=` + pin + ";wskey=" + wskey + ";")
}

function sendHelloWorld(config, key, pin, wskey) {
    if (config.helloWorldBaseUrl && config.helloWorldToken) {
        console.log(`正在发送到helloWorld`)
        __utils.request({
            url: `${config.helloWorldBaseUrl}/openApi/addOrUpdateAccount?api-token=${config.helloWorldToken}`,
            body: {
                ptPin: pin,
                wsKey: wskey,
            },
            method: "post",
        }, (err, info, body) => console.log("helloWorld发送消息结果", err, info, body))
        return true
    }
}

function sendTgBot(config, key, pin, wskey, ok) {
    if (config.tgBotToken && config.tgBotSendToId) {
        let msg = "代理获取到wskey: pin=" + pin + ";wskey=" + wskey + ";"
        if (ok) {
            msg = "代理获取到wskey: " + pin + " ,已推送到其他工具"
        }
        __utils.request({
            url: `${config.tgBotBaseUrl || 'https://api.telegram.org'}/bot${config.tgBotToken}/sendMessage?chat_id=${config.tgBotSendToId}&text=${encodeURIComponent(msg)}`,
            method: "post",
            proxy: config.tgBotProxy || ""
        }, (err, info, body) =>
            console.log("发送到tg完成,结果为:", body, err)
        )
        return true
    }
}

let url = __context.request().originalUrl()
if (url && (url.startsWith("https://api.m.jd.com/client.action?functionId=cart") || url.startsWith("https://api.m.jd.com/api?functionId=lite_cart"))) {
    let res = __context.doRequest();
    let body = res.body();
    let value = `已经获取到wskey,请关闭代理`
    if (!__context.globalGet(key) && __context.globalKeys().filter(k => k.startsWith("wskey-")).filter(k => __context.globalGet(k) === wskey).length === 0) {
        value = `未获取到,打开消息并刷新试试`
    }
    res.setBody(body
        .replace(/"Name":"[^"]+","/g, '"Name":"' + value + '","')
        .replace(/"title":"[^"]+","/g, '"title":"' + value + '","')
        .replace(/"landedPrice":"[^"]+","/g, '"landedPrice":"' + value + '","')
        .replace(/"STip":"[^"]+","/g, '"STip":"' + value + '","')
        .replace(/"shopName":"[^"]+","/g, '"shopName":"' + value + '","')
        .replace(/"accountMessage":"[^"]+","/g, '"accountMessage":"' + value + '","')
        // .replace(/"unitedText":"[^"]+","/g, '"unitedText":"' + value + '","')
        // .replace(/"bottomRuleMsg":"[^"]+","/g, '"bottomRuleMsg":"' + value + '","')
    )
}