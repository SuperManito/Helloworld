//#host:.*
//#order:99999
let arr=[
   /.*.jd.com.*/,
   /.*.360buyimg.com.*/,
   ]
let url = __context.request().originalUrl()
for(let u of arr){
   if(u.test(url)){
		return
   }
}
let res=__context.doBlock()
res.setStatus(500).setHeader("content-type","text/html; charset=UTF-8")
res.setBody("你正在使用代理访问其他内容")
