//#host:.*
//#order:200

__context.continue()
let cookie = __context.request().header('cookie');
if (!cookie || cookie.indexOf('pin') === -1) {
    return
}
let ckObj = cookie.split(";").map(s => s.split("="))
    .reduce((obj, arr) => (obj[(arr[0] + "").trim()] = (arr[1] + "").trim(), obj), {})
let pin = ckObj.pin || ckObj.pt_pin || ckObj.pwdt_id;

let url = __context.request().originalUrl()
if (url && url.startsWith("https://ihelp.jd.com/?sid=")) {
    const key = "wskey-" + pin;
    let wskey = __context.globalGet(key)
    let v;
    if (wskey) {
        v = "pin=" + pin + ";wskey=" + wskey + ";";
    } else {
        v = "未获取到wskey,去 购物车 和 消息列表 页面多刷新几次吧"
    }
    let res = __context.doRequest();
    let body = res.body();
    let replace = (body + "").replace(/>自助服务</g, `><textarea rows="4" cols="45">${v}</textarea><`);
    res.setBody(replace)
}