//#host:.*
//#order:-111
let req = __context.request()
let originalUrl = req.originalUrl();

// if (originalUrl.indexOf(".jd.com")<0) {
//     return
// }

if (req.header("Accept").includes("image")) {
    return
}

let res = __context.doRequest();

if (res.header("Content-Type").includes("image")) {
    return
}

let reqHeaderStr = ""
let resHeaderStr = ""
let headers = req.headers();

for (let k in headers) {
    reqHeaderStr += `${k}: ${headers[k].join("，")}\n`
}
headers = res.headers();
for (let k in headers) {
    resHeaderStr += `${k}: ${headers[k].join("，")}\n`
}
let reqBody = req.body()
if (reqBody) {
    reqBody = "\n\n" + reqBody
}
__utils.appendFile("web/static/访问日志.log", `${originalUrl}\n${reqHeaderStr}${reqBody}\n${res.status()}  ***\n${resHeaderStr}\n\n${res.body()}\n##############\n\n`)
__context.continue()